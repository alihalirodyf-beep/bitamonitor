package com.bitamonitor.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object Scheduler {
    private const val REQ = 7788

    fun scheduleNext(context: Context) {
        if (!AppState.enabled(context) || AppState.foundToday(context)) return
        val now = Calendar.getInstance()
        val next = nextCheckTime(now)
        setAlarm(context, next)
    }

    fun start(context: Context) {
        if (!AppState.enabled(context) || AppState.foundToday(context)) return
        setAlarm(context, nextCheckTime(Calendar.getInstance()))
    }

    private fun nextCheckTime(now: Calendar): Calendar {
        val c = Calendar.getInstance().apply { timeInMillis = now.timeInMillis; set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val h = c.get(Calendar.HOUR_OF_DAY)
        val m = c.get(Calendar.MINUTE)
        val inWindow = (h == 6 && m >= 55) || (h in 7..13 && (m >= 55 || m <= 5)) || (h == 14 && m <= 5)
        if (inWindow) {
            if (now.timeInMillis > c.timeInMillis) c.add(Calendar.MINUTE, 1)
            if (inWindow(c)) return c
        }
        val target = Calendar.getInstance().apply {
            timeInMillis = c.timeInMillis
            when {
                h < 6 || (h == 6 && m < 55) -> { set(Calendar.HOUR_OF_DAY, 6); set(Calendar.MINUTE, 55) }
                h >= 14 -> { add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 6); set(Calendar.MINUTE, 55) }
                else -> { add(Calendar.HOUR_OF_DAY, 1); set(Calendar.MINUTE, 55) }
            }
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        return target
    }

    private fun setAlarm(context: Context, c: Calendar) {
        val pi = PendingIntent.getBroadcast(context, REQ, Intent(context, ScheduleReceiver::class.java).setAction(ScheduleReceiver.ACTION_CHECK), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = context.getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
        else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
    }

    private fun inWindow(c: Calendar): Boolean {
        val h = c.get(Calendar.HOUR_OF_DAY); val m = c.get(Calendar.MINUTE)
        return when (h) {
            6 -> m >= 55
            in 7..13 -> m >= 55 || m <= 5
            14 -> m <= 5
            else -> false
        }
    }
}
