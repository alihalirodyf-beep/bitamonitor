package com.bitamonitor.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.graphics.Rect
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.atomic.AtomicBoolean

class BitaBarAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private var phase = Phase.IDLE
    private var stepStarted = 0L

    enum class Phase { IDLE, WAIT_HOME, FIND_KERMAN, WAIT_AFTER_KERMAN, FIND_SELECT, WAIT_AFTER_SELECT, CHECK_BAR, BACK_TO_SELECT }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or AccessibilityEvent.TYPE_VIEW_SCROLLED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = flags or AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (requestCheck) kick()
    }

    override fun onInterrupt() {}

    fun kick() {
        if (running.get()) return
        requestCheck = false
        if (!AppState.enabled(this) || AppState.foundToday(this) || AppState.paused(this) || !InternetChecker.isOnline(this)) return
        running.set(true)
        phase = Phase.WAIT_HOME
        stepStarted = System.currentTimeMillis()
        openBitaBar()
        handler.postDelayed({ tick() }, 1500)
    }

    private fun tick() {
        if (!running.get()) return
        if (!InternetChecker.isOnline(this)) { stopRun(); return }
        if (AppState.foundToday(this)) { stopRun(); return }
        val root = rootInActiveWindow
        if (root == null) { handler.postDelayed({ tick() }, 1000); return }

        when (phase) {
            Phase.WAIT_HOME -> {
                if (contains(root, "کرمان کرمان") || contains(root, "کرمان")) { phase = Phase.FIND_KERMAN; stepStarted=System.currentTimeMillis() }
                else if (System.currentTimeMillis()-stepStarted > 10000) { openBitaBar(); stepStarted=System.currentTimeMillis() }
            }
            Phase.FIND_KERMAN -> {
                if (clickText(root, "کرمان کرمان", preferExact = true) || clickText(root, "کرمان", preferExact = true)) { phase=Phase.WAIT_AFTER_KERMAN; stepStarted=System.currentTimeMillis() }
                else if (System.currentTimeMillis()-stepStarted > 4000) scroll(root)
            }
            Phase.WAIT_AFTER_KERMAN -> {
                if (System.currentTimeMillis() - stepStarted >= 2000) { phase=Phase.FIND_SELECT; stepStarted=System.currentTimeMillis() }
            }
            Phase.FIND_SELECT -> {
                if (clickText(root, "انتخاب بار", preferExact = true)) { phase=Phase.WAIT_AFTER_SELECT; stepStarted=System.currentTimeMillis() }
                else if (System.currentTimeMillis()-stepStarted > 5000) scroll(root)
            }
            Phase.WAIT_AFTER_SELECT -> {
                if (System.currentTimeMillis() - stepStarted >= 2500) { phase=Phase.CHECK_BAR; stepStarted=System.currentTimeMillis() }
            }
            Phase.CHECK_BAR -> {
                if (contains(root, "بردسیر")) { AppState.markFoundToday(this); NotificationHelper.found(this); stopRun(); return }
                if (contains(root, "باری یافت نشد")) { phase=Phase.BACK_TO_SELECT; stepStarted=System.currentTimeMillis(); performGlobalAction(GLOBAL_ACTION_BACK) }
                else if (System.currentTimeMillis()-stepStarted > 5000) {
                    phase=Phase.BACK_TO_SELECT; performGlobalAction(GLOBAL_ACTION_BACK); stepStarted=System.currentTimeMillis()
                }
            }
            Phase.BACK_TO_SELECT -> {
                if (clickText(root, "انتخاب بار", preferExact = true)) { phase=Phase.CHECK_BAR; stepStarted=System.currentTimeMillis() }
                else if (System.currentTimeMillis()-stepStarted > 5000) { performGlobalAction(GLOBAL_ACTION_BACK); stepStarted=System.currentTimeMillis() }
            }
            Phase.IDLE -> stopRun()
        }
        handler.postDelayed({ tick() }, 1000)
    }

    private fun openBitaBar() {
        val intent = packageManager.getLaunchIntentForPackage(BITA_PACKAGE) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(intent)
    }

    private fun contains(root: AccessibilityNodeInfo, text: String): Boolean = walk(root) { node ->
        normalize(node.text?.toString()).contains(normalize(text)) ||
            normalize(node.contentDescription?.toString()).contains(normalize(text))
    }

    private fun clickText(root: AccessibilityNodeInfo, text: String, preferExact: Boolean): Boolean {
        val node = findNode(root, text, preferExact) ?: return false
        var n: AccessibilityNodeInfo? = node
        repeat(6) {
            if (n?.isClickable == true) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n?.parent
        }
        val r = Rect(); node.getBoundsInScreen(r)
        return clickByGesture(r.centerX().toFloat(), r.centerY().toFloat())
    }


    private fun findNode(root: AccessibilityNodeInfo, text: String, preferExact: Boolean): AccessibilityNodeInfo? {
        val target = normalize(text)
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val n = queue.removeFirst()
            val a = normalize(n.text?.toString())
            val d = normalize(n.contentDescription?.toString())
            if ((preferExact && (a == target || d == target)) || (!preferExact && (a.contains(target) || d.contains(target)))) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let(queue::add)
        }
        return null
    }

    private fun walk(root: AccessibilityNodeInfo, predicate: (AccessibilityNodeInfo) -> Boolean): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val n = queue.removeFirst()
            if (predicate(n)) return true
            for (i in 0 until n.childCount) n.getChild(i)?.let(queue::add)
        }
        return false
    }

    private fun normalize(value: String?): String = value.orEmpty()
        .replace('ي', 'ی').replace('ى', 'ی').replace('ك', 'ک').replace('ۀ', 'ه')
        .replace('ة', 'ه').replace("\u200c", "")
        .trim()

    private fun scroll(root: AccessibilityNodeInfo) {
        var n: AccessibilityNodeInfo? = root
        var candidate: AccessibilityNodeInfo? = null
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val x=queue.removeFirst()
            if (x.isScrollable) { candidate=x; break }
            for(i in 0 until x.childCount) x.getChild(i)?.let(queue::add)
        }
        candidate?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    private fun clickByGesture(x: Float, y: Float): Boolean {
        if (android.os.Build.VERSION.SDK_INT < 24) return false
        val p = android.accessibilityservice.GestureDescription.Builder().addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(android.graphics.Path().apply { moveTo(x,y) },0,50)).build()
        return dispatchGesture(p, null, null)
    }

    private fun stopRun() { running.set(false); handler.removeCallbacksAndMessages(null); phase=Phase.IDLE }

    companion object {
        const val BITA_PACKAGE = "com.hvn7.nobat"
        @Volatile var instance: BitaBarAccessibilityService? = null
        @Volatile var requestCheck: Boolean = false
    }
}
