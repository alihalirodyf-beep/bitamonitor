package com.bitamonitor.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AppState {
    private const val PREF = "state"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_FOUND_DATE = "found_date"
    private const val KEY_PAUSE_UNTIL = "pause_until"

    private fun p(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun enabled(c: Context) = p(c).getBoolean(KEY_ENABLED, true)
    fun setEnabled(c: Context, v: Boolean) { p(c).edit().putBoolean(KEY_ENABLED, v).apply() }

    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    fun foundToday(c: Context) = p(c).getString(KEY_FOUND_DATE, "") == today()
    fun markFoundToday(c: Context) { p(c).edit().putString(KEY_FOUND_DATE, today()).apply() }

    fun pauseUntil(c: Context): Long = p(c).getLong(KEY_PAUSE_UNTIL, 0L)
    fun setPause(c: Context, minutes: Long) { p(c).edit().putLong(KEY_PAUSE_UNTIL, System.currentTimeMillis() + minutes * 60_000L).apply() }
    fun paused(c: Context) = System.currentTimeMillis() < pauseUntil(c)

    fun stopForToday(c: Context) {
        markFoundToday(c)
    }
}
