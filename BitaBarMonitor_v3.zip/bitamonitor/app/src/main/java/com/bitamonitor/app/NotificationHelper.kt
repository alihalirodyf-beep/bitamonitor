package com.bitamonitor.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat

object NotificationHelper {
    const val CHANNEL_ID = "bita_found"

    fun createChannel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
            val ch = NotificationChannel(CHANNEL_ID, "هشدار بار بردسیر", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(uri, attrs)
            ch.enableVibration(true)
            c.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    fun found(c: Context) {
        createChannel(c)
        val nm = c.getSystemService(NotificationManager::class.java)
        val n = NotificationCompat.Builder(c, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("🚨 بار بردسیر پیدا شد")
            .setContentText("بار مقصد بردسیر پیدا شد. بررسی امروز متوقف شد.")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setVibrate(longArrayOf(0, 500, 300, 800, 300, 1200))
            .build()
        nm.notify(2001, n)
    }
}
