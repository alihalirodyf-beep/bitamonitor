package com.bitamonitor.app

import android.Manifest
import android.app.AlarmManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationHelper.createChannel(this)
        requestNotificationPermission()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(32,48,32,32) }
        val title = TextView(this).apply { text = "ربات بی‌تا بار"; textSize = 28f; gravity = Gravity.CENTER; setPadding(0,0,0,30) }
        status = TextView(this).apply { textSize = 18f; gravity = Gravity.CENTER; setPadding(0,0,0,20) }
        root.addView(title)
        root.addView(status)
        root.addView(button("فعال / غیرفعال") { AppState.setEnabled(this, !AppState.enabled(this)); Scheduler.start(this); refresh() })
        root.addView(button("بررسی الآن") { BitaBarAccessibilityService.requestCheck = true; BitaBarAccessibilityService.instance?.kick(); refresh() })
        root.addView(button("توقف تا پایان امروز") { AppState.stopForToday(this); refresh() })
        root.addView(button("توقف ۳۰ دقیقه") { AppState.setPause(this, 30); refresh() })
        root.addView(button("توقف ۱ ساعت") { AppState.setPause(this, 60); refresh() })
        root.addView(button("توقف ۲ ساعت") { AppState.setPause(this, 120); refresh() })
        root.addView(button("فعال‌سازی دسترسی ربات") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(button("بدون محدودیت باتری") {
            if (Build.VERSION.SDK_INT >= 23) startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        })
        root.addView(button("اجازه آلارم دقیق") { if (Build.VERSION.SDK_INT >= 31) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) })
        setContentView(root)
        Scheduler.start(this)
        refresh()
    }

    private fun button(t: String, action: () -> Unit) = Button(this).apply { text=t; setOnClickListener { action() }; layoutParams=LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin=12 } }
    private fun refresh() {
        status.text = when {
            !AppState.enabled(this) -> "وضعیت: غیرفعال"
            AppState.foundToday(this) -> "🚨 امروز بار بردسیر پیدا شده و بررسی متوقف است"
            AppState.paused(this) -> "وضعیت: موقتاً متوقف"
            else -> "وضعیت: فعال\n06:55 تا 14:05، هر ۱ دقیقه"
        }
    }
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
    }
}
