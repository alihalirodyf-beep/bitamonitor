package com.bitamonitor.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == ACTION_CHECK) {
            BitaBarAccessibilityService.requestCheck = true
            BitaBarAccessibilityService.instance?.kick()
            Scheduler.scheduleNext(context)
        }
    }

    companion object { const val ACTION_CHECK = "com.bitamonitor.app.CHECK" }
}
